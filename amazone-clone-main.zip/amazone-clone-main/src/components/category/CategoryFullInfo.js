export const categoryInfos = [
  {
    title: "Elecronics",
    name: "electronics",
    imgLink:
      "https://m.media-amazon.com/images/I/71bPcqUviTL._AC_UY327_FMwebp_QL65_.jpg",
  },
  {
    title: "Discover fashion trends",
    name: "women's clothing",
    imgLink:
      "https://m.media-amazon.com/images/I/71KNJ3m75KL._AC_UL480_FMwebp_QL65_.jpg",
  },
  {
    title: "Men's clothing",
    name: "men's clothing",
    imgLink: "https://m.media-amazon.com/images/I/716CxxUFUxL._AC_SX569_.jpg",
  },
  {
    title: "Jewelery",
    name: "jewelery",
    imgLink:
      "https://m.media-amazon.com/images/I/71r7eWuCsaL._AC_UL480_FMwebp_QL65_.jpg",
  },
];
