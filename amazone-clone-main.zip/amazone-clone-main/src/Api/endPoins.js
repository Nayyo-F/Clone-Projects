export const productUrl = "https://fakestoreapi.com";
